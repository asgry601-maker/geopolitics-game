@echo off
rem ابزار تشخیصی DEBUG4 — بدون تغییر کد بازی
rem ممیزی تک‌تک Spriteهای برچسب استان با روش تفاضلی + renderer.info
rem این سرور کوچک فقط فایل‌های همین پوشهٔ بازی را سرو می‌کند (پورت 8126)
cd /d "%~dp0\.."
start "" /min cmd /c "python -m http.server 8126 --bind 127.0.0.1"
ping -n 3 127.0.0.1 >nul
start "" "http://127.0.0.1:8126/PROV-LABEL-DEBUG4.html"
echo اگر صفحه باز نشد، در مرورگر آدرس http://127.0.0.1:8126/PROV-LABEL-DEBUG4.html را باز کنید.
echo توجه: تا پایان تست، پنجرهٔ مرورگر را فعال نگه دارید (تب پس‌زمینه rAF را متوقف می‌کند).
pause
