@echo off
rem ابزار تشخیصی DEBUG4.1 — بدون تغییر کد بازی
rem FIX v4.1: خطای ReferenceError: done در پایان گزارش ابزار DEBUG4 رفع شد (امضای auditF)
rem این سرور کوچک فقط فایل‌های همین پوشهٔ بازی را سرو می‌کند (پورت 8127)
cd /d "%~dp0\.."
start "" /min cmd /c "python -m http.server 8127 --bind 127.0.0.1"
ping -n 3 127.0.0.1 >nul
start "" "http://127.0.0.1:8127/PROV-LABEL-DEBUG4.1.html"
echo اگر صفحه باز نشد، در مرورگر آدرس http://127.0.0.1:8127/PROV-LABEL-DEBUG4.1.html را باز کنید.
echo توجه: تا پایان تست، پنجرهٔ مرورگر را فعال نگه دارید (تب پس‌زمینه rAF را متوقف می‌کند).
pause
