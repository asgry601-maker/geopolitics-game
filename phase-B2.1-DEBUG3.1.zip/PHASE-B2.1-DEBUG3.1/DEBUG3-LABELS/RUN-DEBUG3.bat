@echo off
rem ابزار تشخیصی DEBUG3.1 — بدون تغییر کد بازی
rem اصلاح v3.1: بازنویسی مسیر src="world.js" به world/world.js در حافظهٔ iframe (همان راه‌حل DEBUG2)
rem این سرور کوچک فقط فایل‌های همین پوشهٔ بازی را برای DEBUG سرو می‌کند (پورت 8125)
cd /d "%~dp0\.."
start "" /min cmd /c "python -m http.server 8125 --bind 127.0.0.1"
ping -n 3 127.0.0.1 >nul
start "" "http://127.0.0.1:8125/PROV-LABEL-DEBUG3.html"
echo اگر صفحه باز نشد، در مرورگر آدرس http://127.0.0.1:8125/PROV-LABEL-DEBUG3.html را باز کنید.
echo توجه: تا پایان تست، پنجرهٔ مرورگر را فعال نگه دارید (تب پس‌زمینه rAF را متوقف می‌کند).
pause
