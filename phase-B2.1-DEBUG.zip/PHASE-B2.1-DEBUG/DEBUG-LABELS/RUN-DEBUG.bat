@echo off
rem ابزار تشخیصی برچسب استان‌ها — بدون تغییر کد بازی
rem این سرور کوچک فقط فایل‌های همین پوشهٔ بازی را برای DEBUG سرو می‌کند (پورت 8123)
cd /d "%~dp0\.."
start "" /min cmd /c "python -m http.server 8123 --bind 127.0.0.1"
ping -n 3 127.0.0.1 >nul
start "" "http://127.0.0.1:8123/PROV-LABEL-DEBUG.html"
echo اگر صفحه باز نشد، در مرورگر آدرس http://127.0.0.1:8123/PROV-LABEL-DEBUG.html را باز کنید.
pause
