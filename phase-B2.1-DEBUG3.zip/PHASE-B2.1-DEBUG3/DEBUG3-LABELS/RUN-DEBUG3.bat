@echo off
rem ابزار تشخیصی DEBUG3 — بدون تغییر کد بازی
rem این سرور کوچک فقط فایل‌های همین پوشهٔ بازی را برای DEBUG سرو می‌کند (پورت 8124)
cd /d "%~dp0\.."
start "" /min cmd /c "python -m http.server 8124 --bind 127.0.0.1"
ping -n 3 127.0.0.1 >nul
start "" "http://127.0.0.1:8124/PROV-LABEL-DEBUG3.html"
echo اگر صفحه باز نشد، در مرورگر آدرس http://127.0.0.1:8124/PROV-LABEL-DEBUG3.html را باز کنید.
echo توجه: تا پایان تست، پنجرهٔ مرورگر را فعال نگه دارید (تب پس‌زمینه rAF را متوقف می‌کند).
pause
